const fs = require('fs');
const path = require('path');
const https = require('https');

const rootDir = path.resolve(__dirname, '..');
const localesDir = path.join(rootDir, 'locales');
const viewsDir = path.join(rootDir, 'views');
const controllersDir = path.join(rootDir, 'controllers');

const supportedLangs = ['tr', 'en', 'el', 'ru', 'fa'];

function loadJson(lang) {
  const filePath = path.join(localesDir, `${lang}.json`);
  if (!fs.existsSync(filePath)) return {};
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (err) {
    console.error(`Error parsing ${lang}.json:`, err.message);
    return {};
  }
}

function saveJson(lang, data) {
  const filePath = path.join(localesDir, `${lang}.json`);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2) + '\n', 'utf8');
}

function isObject(item) {
  return item && typeof item === 'object' && !Array.isArray(item);
}

function getAllKeys(obj, prefix = '') {
  let keys = [];
  for (const k in obj) {
    const full = prefix ? `${prefix}.${k}` : k;
    if (isObject(obj[k])) {
      keys = keys.concat(getAllKeys(obj[k], full));
    } else if (Array.isArray(obj[k])) {
      obj[k].forEach((_, idx) => {
        keys.push(`${full}.${idx}`);
      });
    } else {
      keys.push(full);
    }
  }
  return keys;
}

function getNestedValue(obj, keyPath) {
  const keys = keyPath.split('.');
  let current = obj;
  for (const k of keys) {
    if (current && (typeof current === 'object' || Array.isArray(current)) && k in current) {
      current = current[k];
    } else {
      return undefined;
    }
  }
  return typeof current === 'string' || typeof current === 'number' ? String(current) : undefined;
}

function setNestedValue(obj, keyPath, value) {
  const keys = keyPath.split('.');
  let current = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    const nextKeyIsNum = !isNaN(Number(keys[i + 1]));
    if (!current[k] || (typeof current[k] !== 'object' && !Array.isArray(current[k]))) {
      current[k] = nextKeyIsNum ? [] : {};
    }
    current = current[k];
  }
  const lastKey = keys[keys.length - 1];
  current[lastKey] = value;
}

function sortObject(obj) {
  if (Array.isArray(obj)) {
    return obj.map(item => sortObject(item));
  }
  if (!isObject(obj)) return obj;
  const sorted = {};
  Object.keys(obj).sort().forEach(key => {
    if (isObject(obj[key]) || Array.isArray(obj[key])) {
      sorted[key] = sortObject(obj[key]);
    } else {
      sorted[key] = obj[key];
    }
  });
  return sorted;
}

function translateText(text, targetLang) {
  return new Promise((resolve) => {
    if (!text || typeof text !== 'string') return resolve(text);
    
    // Protect parameters like {name}, {count}
    const paramMatches = [];
    const protectedText = text.replace(/\{([a-zA-Z0-9_]+)\}/g, (match) => {
      paramMatches.push(match);
      return `___PARAM_${paramMatches.length - 1}___`;
    });

    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=tr&tl=${targetLang}&dt=t&q=${encodeURIComponent(protectedText)}`;
    
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          let translated = parsed[0].map(x => x[0]).join('');
          
          // Restore parameters
          paramMatches.forEach((param, idx) => {
            translated = translated.replace(new RegExp(`___PARAM_${idx}___|___ PARAM_${idx} ___`, 'gi'), param);
          });

          resolve(translated.trim());
        } catch (e) {
          resolve(text); // Fallback to original text on error
        }
      });
    }).on('error', () => resolve(text));
  });
}

// COMMAND 1: CHECK
function checkCmd() {
  console.log('🔍 Checking i18n locale files key parity...\n');
  const locales = {};
  const keysPerLang = {};
  
  supportedLangs.forEach(lang => {
    locales[lang] = loadJson(lang);
    keysPerLang[lang] = new Set(getAllKeys(locales[lang]));
  });

  const trKeys = keysPerLang['tr'];
  let totalMissing = 0;

  console.log(`TR (Base Language) total keys: ${trKeys.size}`);

  supportedLangs.forEach(lang => {
    if (lang === 'tr') return;
    const langKeys = keysPerLang[lang];
    const missingInLang = [...trKeys].filter(k => !langKeys.has(k));
    const extraInLang = [...langKeys].filter(k => !trKeys.has(k));

    console.log(`\n--- Language: ${lang.toUpperCase()} ---`);
    console.log(`Total keys: ${langKeys.size}`);
    
    if (missingInLang.length > 0) {
      console.log(`❌ Missing keys compared to TR (${missingInLang.length}):`);
      missingInLang.slice(0, 10).forEach(k => console.log(`   - ${k}`));
      if (missingInLang.length > 10) console.log(`   ... and ${missingInLang.length - 10} more`);
      totalMissing += missingInLang.length;
    } else {
      console.log(`✅ All ${trKeys.size} keys present.`);
    }

    if (extraInLang.length > 0) {
      console.log(`⚠️ Extra keys not in TR (${extraInLang.length}):`);
      extraInLang.slice(0, 5).forEach(k => console.log(`   - ${k}`));
    }
  });

  console.log(`\n========================================`);
  if (totalMissing === 0) {
    console.log(`🎉 100% Key Parity across all languages!`);
  } else {
    console.log(`⚠️ Found ${totalMissing} missing keys across languages. Run 'npm run i18n:sync' to fix.`);
    process.exit(1);
  }
}

// COMMAND 2: SYNC
async function syncCmd() {
  console.log('🔄 Syncing and translating locale files based on tr.json...\n');
  const trData = loadJson('tr');
  const trKeys = getAllKeys(trData);

  console.log(`Loaded ${trKeys.length} keys from tr.json.`);

  for (const lang of supportedLangs) {
    if (lang === 'tr') {
      saveJson('tr', sortObject(trData));
      continue;
    }

    console.log(`\nProcessing language '${lang.toUpperCase()}'...`);
    const langData = loadJson(lang);
    let addedCount = 0;

    for (const key of trKeys) {
      const existingVal = getNestedValue(langData, key);
      if (existingVal === undefined) {
        const trVal = getNestedValue(trData, key);
        if (trVal) {
          process.stdout.write(`  Translating '${key}'... `);
          const translatedVal = await translateText(trVal, lang);
          setNestedValue(langData, key, translatedVal);
          console.log(`-> "${translatedVal}"`);
          addedCount++;
        }
      }
    }

    saveJson(lang, sortObject(langData));
    console.log(`✅ Finished '${lang.toUpperCase()}': ${addedCount} new translations added.`);
  }

  console.log('\n🎉 Sync completed for all languages!');
}

// COMMAND 3: SCAN
function findFiles(dir, ext) {
  let results = [];
  if (!fs.existsSync(dir)) return results;
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      results = results.concat(findFiles(fullPath, ext));
    } else if (file.endsWith(ext)) {
      results.push(fullPath);
    }
  });
  return results;
}

function scanCmd() {
  console.log('🔎 Scanning code for hardcoded text and unregistered t() keys...\n');
  const ejsFiles = findFiles(viewsDir, '.ejs');
  const jsFiles = findFiles(controllersDir, '.js');
  const trData = loadJson('tr');

  const registeredKeys = new Set(getAllKeys(trData));
  const usedKeys = new Map();

  // The `t` must not be the tail of a longer identifier, otherwise the `t(` at
  // the end of `redirect('/admin')` and `createElement('div')` is read as a
  // translation call and the report fills with URLs and tag names — which is
  // exactly why a real missing key could sit in this output unnoticed.
  const regexes = [
    /(?<![\w$.])t\(\s*(['"])([^'"]+)\1/g,
    /(?<![\w$.])__\(\s*(['"])([^'"]+)\1/g
  ];

  [...ejsFiles, ...jsFiles].forEach(filePath => {
    const content = fs.readFileSync(filePath, 'utf8');
    const relPath = path.relative(rootDir, filePath).split(path.sep).join('/');

    regexes.forEach(regex => {
      let match;
      while ((match = regex.exec(content)) !== null) {
        const key = match[2];

        // Keys assembled at render time — t('bids.status_' + bid.status) — reach
        // here as a bare prefix. The prefix itself is never a real key.
        if (/[._]$/.test(key)) continue;
        if (!/^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)*$/.test(key)) continue;

        const line = content.slice(0, match.index).split('\n').length;
        if (!usedKeys.has(key)) usedKeys.set(key, []);
        usedKeys.get(key).push(`${relPath}:${line}`);
      }
    });
  });

  const namespaces = ['nav', 'common', 'listing', 'auth', 'categories', 'home', 'footer', 'admin', 'pages', 'profile_edit', 'report_modal'];

  // getAllKeys expands an array value into indexed leaves (smart.placeholders.0,
  // .1, …) so parity can be checked element by element. That leaves the array's
  // own name absent from the set, and a template that legitimately asks for the
  // whole list would be reported as missing.
  const isArrayKey = (key) => registeredKeys.has(`${key}.0`);

  const unregistered = [...usedKeys.entries()].filter(([key]) => {
    if (registeredKeys.has(key) || isArrayKey(key)) return false;
    return !namespaces.some(ns => registeredKeys.has(`${ns}.${key}`) || isArrayKey(`${ns}.${key}`));
  });

  if (unregistered.length > 0) {
    console.log(`⚠️ Used t() keys missing from tr.json (${unregistered.length}):`);
    unregistered.forEach(([key, places]) => {
      console.log(`   - ${key}`);
      console.log(`     ${places.join(', ')}`);
    });
    process.exitCode = 1;
  } else {
    console.log(`✅ All t() keys in code exist in tr.json.`);
  }

  console.log(`\nScanning EJS files for remaining hardcoded text...`);
  let hardcodedTotal = 0;

  ejsFiles.forEach(filePath => {
    const content = fs.readFileSync(filePath, 'utf8');
    const relPath = path.relative(rootDir, filePath);
    const lines = content.split('\n');
    const lineHits = [];

    lines.forEach((line, idx) => {
      const cleanLine = line.replace(/<%[\s\S]*?%>/g, '')
                            .replace(/<[^>]+>/g, '')
                            .trim();
      if (cleanLine.length > 2 && /[a-zA-ZçğıöşüÇĞİÖŞÜ]/.test(cleanLine)) {
        if (!cleanLine.startsWith('{') && !cleanLine.startsWith('//') && !cleanLine.startsWith('<!--') && !cleanLine.startsWith('const ') && !cleanLine.startsWith('let ') && !cleanLine.startsWith('var ') && !cleanLine.includes('http')) {
          lineHits.push({ line: idx + 1, text: cleanLine });
        }
      }
    });

    if (lineHits.length > 0) {
      hardcodedTotal += lineHits.length;
      console.log(`\n📄 ${relPath} (${lineHits.length} candidates):`);
      lineHits.slice(0, 3).forEach(h => console.log(`   L${h.line}: "${h.text}"`));
    }
  });

  console.log(`\n========================================`);
  console.log(`Total hardcoded candidates remaining: ${hardcodedTotal}`);
}

const command = process.argv[2] || 'check';

if (command === 'check') {
  checkCmd();
} else if (command === 'sync') {
  syncCmd();
} else if (command === 'scan') {
  scanCmd();
} else {
  console.log('Usage: node scripts/i18n-tool.js [check|sync|scan]');
}
